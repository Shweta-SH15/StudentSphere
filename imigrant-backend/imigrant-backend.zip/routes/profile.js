const express = require("express");
const router = express.Router();
const verifyFirebaseToken = require("../middleware/firebaseAuth");
const User = require("../models/User"); // assuming Mongoose

// GET profile
router.get("/", verifyFirebaseToken, async (req, res) => {
  const user = await User.findOne({ email: req.user.email }); // or uid if stored
  res.json(user);
});

// PUT update profile
router.put("/", verifyFirebaseToken, async (req, res) => {
  const updated = await User.findOneAndUpdate(
    { email: req.user.email },
    req.body,
    { new: true }
  );
  res.json(updated);
});

module.exports = router;
