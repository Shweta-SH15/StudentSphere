module.exports = {
    jwtSecret: process.env.JWT_SECRET || 'yoursecret',
    mongoURI: process.env.MONGO_URI || 'your-mongo-uri-here'
};
export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:5000/api";
export const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || "http://localhost:5000";
