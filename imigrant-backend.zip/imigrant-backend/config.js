module.exports = {
    mongoURI: process.env.MONGO_URI || 'your-mongo-uri-here'
};
